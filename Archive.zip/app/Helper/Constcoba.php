<?php
 
namespace App\Helper;

class Constcoba{
    const VITAMIN = 'Berikan vitamin';
    const BIOTIK = 'Berikan anti biotik';
    const CACING = 'Berikan obat cacing';
    const RECORDING = 'Recording/performa';

    const nilai_vitamin = array(3,6,18,21,25);
    const nilai_anti_biotik = array(21,25);
    const nilai_obat_cacing = array(3,6,18,21,25);
    const nilai_recording = array(6,21);
}