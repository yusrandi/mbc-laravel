<?php

namespace App\Http\Controllers;

use App\Models\Strow;
use Illuminate\Http\Request;

class StrowController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Models\Strow  $strow
     * @return \Illuminate\Http\Response
     */
    public function show(Strow $strow)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Models\Strow  $strow
     * @return \Illuminate\Http\Response
     */
    public function edit(Strow $strow)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Models\Strow  $strow
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, Strow $strow)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Models\Strow  $strow
     * @return \Illuminate\Http\Response
     */
    public function destroy(Strow $strow)
    {
        //
    }
}
