<?php

namespace Database\Factories;

use App\Models\Ternak;
use Illuminate\Database\Eloquent\Factories\Factory;

class TernakFactory extends Factory
{
    /**
     * The name of the factory's corresponding model.
     *
     * @var string
     */
    protected $model = Ternak::class;

    /**
     * Define the model's default state.
     *
     * @return array
     */
    public function definition()
    {
        return [
            //
        ];
    }
}
