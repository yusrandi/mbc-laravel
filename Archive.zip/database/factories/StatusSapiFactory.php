<?php

namespace Database\Factories;

use App\Models\StatusSapi;
use Illuminate\Database\Eloquent\Factories\Factory;

class StatusSapiFactory extends Factory
{
    /**
     * The name of the factory's corresponding model.
     *
     * @var string
     */
    protected $model = StatusSapi::class;

    /**
     * Define the model's default state.
     *
     * @return array
     */
    public function definition()
    {
        return [
            //
        ];
    }
}
